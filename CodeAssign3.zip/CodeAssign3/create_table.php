<?php
 include_once('connect.php');
 $query_string='
  CREATE TABLE Users (
	user_id int AUTO_INCREMENT PRIMARY KEY,
	fname varchar (30),
	lname varchar (30),
	gender varchar (10),
	username varchar(30),
    password varchar(40),
	email varchar(60),
	phone int(10),
	user_role varchar (30)
	 
  )
   ';

   if($help_conn->query($query_string)){
	   
	   echo "Table successfully created";
   }
?>

<!doctype html>
<html>
<body>
</body>
</html>