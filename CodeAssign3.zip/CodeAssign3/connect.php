<?php
$help_conn=new mysqli('localhost','Sysadmin','admin','helpdesk');
  if($help_conn->connect_errno){
	  
	  echo "Error".$help_conn->connect_errno." has occured";
	  
  }else{
	  
	
  }
	
?>