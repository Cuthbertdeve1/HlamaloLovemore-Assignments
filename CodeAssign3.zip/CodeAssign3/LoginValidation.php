<?php
 
 
 if($_POST['username']=='admin' && $_POST['password']=='admin'){
	 
	 ?>
	 <a href="FormProject.php?username=<?php echo $_POST['username']?>">
	 Go to User Registration
	 </a>
	 <?php
 }
else{
	?>
		<a href="Login.php">Login Failed, Try again</a>
		<?php
}

?>