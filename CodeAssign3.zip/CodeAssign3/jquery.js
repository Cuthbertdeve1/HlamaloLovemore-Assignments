$(function(){
	$("#err_fname").hide();
    $("#err_lname").hide();
	$("#err_uname").hide();
	$("#err_pass").hide();
	$("#err_pass_retype").hide();
	$("#err_email").hide();
	$("#err_email_retype").hide();
	
	
	var err_fname = false;
	var err_lname = false;
	var err_uname = false;
	var err_pass = false;
	var err_pass_retype = false;
	var err_email = false;
	var err_email_retype = false;
	
	
	$("#fname").focusout(function(){
		check_fname();
	})
	
	$("#lname").focusout(function(){
		check_lname();
	})
	$("#username").focusout(function(){
		check_username();
	})
	$("#password").focusout(function(){
		check_password();
	})
	
	$("#password2").focusout(function(){
		check_password2();
	});
	
	
	$("#email").focusout(function(){
		check_email();
	})
	$("#email2").focusout(function(){
		check_email2();
	})
	function check_fname(){
		var fname_length =$("#fname").val().length;
		if(fname_length<1){
			$("#err_fname").html("Enter at least 1 character");
			$("#err_fname").show();
			err_fname =true;
		}else{
			$("#err_fname").hide();
		}
	}
	function check_lname(){
		var lname_length =$("#lname").val().length;
		if(lname_length<1){
			$("#err_lname").html("Enter at least 1 character");
			$("#err_lname").show();
			err_lname =true;
		}else{
			$("#err_lname").hide();
		}
	}
	
	function check_username(){
		var username_length =$("#username").val().length;
		if(username_length<5 || username_length > 20){
			$("#err_uname").html("should be between 5-20 characters");
			$("#err_uname").show();
			err_uname =true;
		}else{
			$("#err_uname").hide();
		}
	}
	function check_password(){
		var password_length = $("#password").val().length;
		if(password_length < 8){
		$("#err_pass").html("At least 8 characters");
		$("#err_pass").show();
		err_pass = true;
		
	}else {
		$("#err_pass").hide();
	}
	}
	function check_password2(){
		var password2 = $("#password2").val();
		var password2 = $("#retype_err_pass").val();
		if(password != password2){
		$("#retype_err_pass").html("Passwords don't match");
		$("#retype_err_pass").show();
		err_pass_retype = true;
		
	}else {
		$("#retype_err_pass").hide();
	}
	}
	
	function check_email(){
		var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
		if(pattern.test($("#email").val())){
			$("err_email").hide();
			
		}else{
			$("#err_email").html("invalid email address");
			$("#err_email").show();
			err_email = true;
		}
	}
	function check_email2(){
		var email2 = $("#email2").val();
		var email2 = $("#err_email2").val();
		if(email != email2){
		$("#err_email_retype").html("Emails don't match");
		$("#err_email_retype").show();
		err_email_retype = true;
		
	}else {
		$("#err_email_retype").hide();
	}
	}
	
	$("#regform").submit(function(){
		err_fname=false;
		err_lname=false;
		err_uname = false;
		err_pass = false;
		err_pass_retype= false;
		err_email =false;
		err_email_retype=false;
		
		check_fname();
		check_lname();
		check_username();
		check_password();
		check_password2();
		check_email();
		check_email2();
		if(err_fname == false && err_lname == false && err_uname == false && err_pass == false && err_pass_retype == false && err_email == false && err_email_retype){
			return true;
		}else{
			return false;
		}
	})
});