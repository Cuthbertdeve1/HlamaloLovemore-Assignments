<?php
include_once('connect.php');
$fname =$_POST["fname"];
$lname =$_POST["lname"];
$gender =$_POST["gender"];
$username =$_POST["username"];
$password =$_POST["password"];
$password2 =$_POST["password2"];
$email =$_POST["email"];
$pnumber =$_POST["pnumber"];
$userrole =$_POST["userrole"];



 $query_string="
 INSERT INTO users
 Values ('','$fname','$lname','$gender','$username','$password','$email','$pnumber','$userrole')
   ";

   if($help_conn->query($query_string)){
	   
	   echo "Data inserted successfully";
   }
   //$_SESSION['welcome'] = $index;
 //header("Location: main_page/index.php")
	  ?>
	<html>
	<body>
	</body>
	</html>
 
 
 